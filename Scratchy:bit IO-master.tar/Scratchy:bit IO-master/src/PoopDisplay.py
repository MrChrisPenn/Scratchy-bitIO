import socket
import time
import sys

class PoopDisplay:

    # optional host & port values
    # defaults to localhost/42001 (local Scratch program)
    def __init__(self, host=None, port=None):
        if host is None:
            self.host = 'localhost'
        else:
             self.host = host 
        if port is None:
            self.port = 42001
        else:
             self.port = port
        self.socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM);
        self.total_pledged = 0
        self.pledge_count = 0

    # create the TCP connection
    def connect(self):
        try:
            self.socket.connect((self.host, self.port))
        except Exception as msg:
            print ("Can't connect to Scratch. Have you started Scratch AND enabled remote sensors? %s " % msg )
            sys.exit(1)
        
    def sendCMD(self,cmd):
        self.socket.send(len(cmd).to_bytes(4, 'big'))
        self.socket.send(bytes(cmd,'UTF-8'))

        

    def A_Pressed(self):
        self.sendCMD( 'broadcast  "a"' )

    def B_Pressed(self):
        self.sendCMD( 'broadcast  "b"' )

    def Pin_0(self):
        self.sendCMD( 'broadcast  "Pin_0"' )

    def Pin_1(self):
        self.sendCMD( 'broadcast  "Pin_1"' )

    def Pin_2(self):
        self.sendCMD( 'broadcast  "Pin_2"' )

