from PoopDisplay import PoopDisplay # import the PoopDisplay class definitionn
import time
import microbit


display= PoopDisplay()    # instantiate a PoopDisplay object
display.connect()         # connect to Scratch (
#display.initialise()      # initialise numerals & sprites

#display.test(2,100,5)   # simulate a set of donation updates
                        # (£2 received from 100 donors, 5 donations per seond)

totalPledged = 10
pledgeCount  = 20


while True:
    time.sleep(0.25)
    if microbit.button_a.was_pressed():
        print("A pressed")
        display.A_Pressed()

    if microbit.button_b.was_pressed():
        time.sleep(0.5)
        print("B pressed")
        display.B_Pressed()

    if microbit.pin0.is_touched():
        print("touching pin 0")
        display.Pin_0()
        time.sleep(3)
    elif microbit.pin1.is_touched():
        print("touching pin 1")
        display.Pin_1()
        time.sleep(3)
        
    elif microbit.pin2.is_touched():
        print("touching pin 2")
        display.Pin_2()
        time.sleep(3)

