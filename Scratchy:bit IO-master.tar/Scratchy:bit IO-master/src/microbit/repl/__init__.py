# repl/__init__.py

try:
    from repl import *
except ImportError:
    from .repl import *
# END
